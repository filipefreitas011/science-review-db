/*
EXPLORAÇÃO DE METADADOS

Executar depois do schema.sql e de todos os populates.

Como rodar no pgAdmin: o Query Tool mostra só o resultado do ÚLTIMO SELECT do script.
Por isso, selecione UMA consulta por vez (do SELECT até o ponto e vírgula) e aperte F5.

- information_schema: catálogo padrão do SQL (ISO), igual em vários SGBDs.
- pg_catalog / pg_stat_*: catálogo próprio do PostgreSQL (tamanho em disco, índices, estatísticas).
*/

/* Atualiza as estatísticas das tabelas, para as contagens da consulta 7 ficarem exatas */
ANALYZE;

/* ---------------------------------------------------------------
   1) Tabelas criadas no esquema public
   --------------------------------------------------------------- */
SELECT table_name, table_type
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;

/* ---------------------------------------------------------------
   2) Colunas de cada tabela: tipo, tamanho, se aceita NULL e valor padrão
   --------------------------------------------------------------- */
SELECT table_name,
       column_name,
       data_type,
       character_maximum_length AS tamanho_texto,
       numeric_precision AS precisao,
       numeric_scale AS casas_decimais,
       is_nullable AS aceita_nulo,
       column_default AS valor_padrao
FROM information_schema.columns
WHERE table_schema = 'public'
ORDER BY table_name, ordinal_position;

/* ---------------------------------------------------------------
   3) Chaves primárias, únicas e estrangeiras, com as colunas envolvidas
   --------------------------------------------------------------- */
SELECT tc.table_name,
       tc.constraint_type,
       tc.constraint_name,
       kcu.column_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
     ON kcu.constraint_name = tc.constraint_name
    AND kcu.table_schema = tc.table_schema
WHERE tc.table_schema = 'public'
ORDER BY tc.table_name, tc.constraint_type, tc.constraint_name, kcu.ordinal_position;

/* ---------------------------------------------------------------
   4) Para onde cada chave estrangeira aponta (tabela e coluna de origem -> destino)
   --------------------------------------------------------------- */
SELECT kcu.table_name AS tabela_origem,
       kcu.column_name AS coluna_origem,
       ccu.table_name AS tabela_destino,
       ccu.column_name AS coluna_destino
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
     ON kcu.constraint_name = tc.constraint_name
    AND kcu.table_schema = tc.table_schema
JOIN information_schema.constraint_column_usage ccu
     ON ccu.constraint_name = tc.constraint_name
    AND ccu.table_schema = tc.table_schema
WHERE tc.table_schema = 'public'
  AND tc.constraint_type = 'FOREIGN KEY'
ORDER BY tabela_origem, coluna_origem;

/* ---------------------------------------------------------------
   5) Restrições CHECK (regras de domínio) e a condição de cada uma.
      O PostgreSQL também lista os NOT NULL como CHECK; eles são filtrados aqui.
   --------------------------------------------------------------- */
SELECT tc.table_name,
       cc.constraint_name,
       cc.check_clause
FROM information_schema.check_constraints cc
JOIN information_schema.table_constraints tc
     ON tc.constraint_name = cc.constraint_name
    AND tc.constraint_schema = cc.constraint_schema
WHERE cc.constraint_schema = 'public'
  AND cc.constraint_name NOT LIKE '%_not_null'
ORDER BY tc.table_name, cc.constraint_name;

/* ---------------------------------------------------------------
   6) Índices: os criados automaticamente (PK e UNIQUE, terminam em _pkey e _key)
      e os criados no schema.sql para as chaves estrangeiras (começam com idx_)
   --------------------------------------------------------------- */
SELECT tablename AS tabela,
       indexname AS indice,
       indexdef AS definicao
FROM pg_indexes
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

/* ---------------------------------------------------------------
   7) Quantidade de linhas e espaço em disco de cada tabela
      (dados, índices e total), da maior para a menor
   --------------------------------------------------------------- */
SELECT relname AS tabela,
       n_live_tup AS linhas,
       pg_size_pretty(pg_relation_size(relid)) AS tamanho_dados,
       pg_size_pretty(pg_indexes_size(relid)) AS tamanho_indices,
       pg_size_pretty(pg_total_relation_size(relid)) AS tamanho_total
FROM pg_stat_user_tables
ORDER BY n_live_tup DESC;
